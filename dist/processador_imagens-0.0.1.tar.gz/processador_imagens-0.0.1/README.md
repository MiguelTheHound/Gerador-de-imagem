# processador_imagem

Description. 
The package processador_imagem is used to:
	- Processing
		- Histogram match
		- Structural similarity
		-Resize images
	Utils
		-Read image
		-Save image
		-Plot image
		-Plot Result
		-Plot Histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```

## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
```

## Author
Miguel

## License
[MIT](https://choosealicense.com/licenses/mit/)#   G e r a d o r - d e - i m a g e m 
 
 